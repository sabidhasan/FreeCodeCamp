A Pen created at CodePen.io. You can find this one at https://codepen.io/abidhasan/pen/JORGNo.

 This pens lets you search for a term on Wikipedia, displays a summary of the articles found, and can open the full article.